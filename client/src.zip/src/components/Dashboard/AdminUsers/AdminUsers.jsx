import React from 'react'
import NavAdmin from '../NavAdmin/NavAdmin'

export const AdminUsers = () => {
  return (
    <div>
      <NavAdmin/>
    </div>
  )
}
